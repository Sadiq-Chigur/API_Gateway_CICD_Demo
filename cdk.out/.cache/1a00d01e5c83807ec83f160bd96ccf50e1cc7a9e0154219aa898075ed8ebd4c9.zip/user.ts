export const handler = async (event: any) => {
  return {
    statusCode: 201,
    body: 'User created!',
  };
};